const menuButton = document.querySelector('.menu-toggle');
const navLinks = document.querySelector('.nav-links');
const themeButton = document.querySelector('.theme-toggle');

menuButton.addEventListener('click', () => {
  const isOpen = navLinks.classList.toggle('open');
  menuButton.setAttribute('aria-expanded', String(isOpen));
  menuButton.textContent = isOpen ? '✕' : '☰';
});

document.querySelectorAll('.nav-links a').forEach(link => {
  link.addEventListener('click', () => {
    navLinks.classList.remove('open');
    menuButton.setAttribute('aria-expanded', 'false');
    menuButton.textContent = '☰';
  });
});

themeButton.addEventListener('click', () => {
  document.body.classList.toggle('light');
  const lightMode = document.body.classList.contains('light');
  themeButton.textContent = lightMode ? '☀' : '☾';
  localStorage.setItem('chinzzy-theme', lightMode ? 'light' : 'dark');
});

if (localStorage.getItem('chinzzy-theme') === 'light') {
  document.body.classList.add('light');
  themeButton.textContent = '☀';
}

document.getElementById('year').textContent = new Date().getFullYear();
